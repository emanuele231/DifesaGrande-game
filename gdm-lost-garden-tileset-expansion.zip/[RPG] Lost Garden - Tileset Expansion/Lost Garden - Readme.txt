Asset Pack Title: Lost Garden - Tileset Expansion
Category: Tileset Expansion
Graphic Style: Retro, pixel

This asset pack is best used with The Dark Dungeon tileset.
This tileset features plant overgrowth, leaves, different kinds of fountains, and small patches of grass.

--

This package contains:
- 100+ tiles; 16x16 each
- 1x, 2x, and 3x scale

--

How to use:
- Extract the tileset
- Import the tileset in your game editor and make sure to set the tile dimensions to 16x16

--

Disclaimer:
This tileset was originally commissioned by Benjamin Belau (@pixelgunk on Twitter) with a non-exclusive license. He gave permission and encouraged the creator to make this asset available for the public to purchase and use for their own projects, commercial and/or otherwise.